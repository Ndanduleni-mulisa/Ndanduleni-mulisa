﻿Imports System.Data
Imports System.Data.SqlClient


Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim con As SqlConnection = New SqlConnection("Data Source=DESKTOP-4JIHRLV;Initial Catalog=ATM_db;Integrated Security=True")
        Dim cmd As SqlCommand = New SqlCommand("SELECT * FROM CUSTOMER WHERE UserName='" + txtUser.Text + "' and Password='" + txtPass.Text + "'", con)
        Dim sda As SqlDataAdapter = New SqlDataAdapter(cmd)
        Dim dt As DataTable = New DataTable()
        sda.Fill(dt)

        If (dt.Rows.Count > 0) Then
            MessageBox.Show("log in successfull")
            Dim tts = CreateObject("SAPI.spvoice")
            tts.speak("log in succesfuly")

            Form2.Show()

        Else
            MessageBox.Show("incorrect UserName or Password")
            Dim tts = CreateObject("SAPI.spvoice")
            tts.speak("Incorrect UserName or Password")

        End If




    End Sub
End Class
