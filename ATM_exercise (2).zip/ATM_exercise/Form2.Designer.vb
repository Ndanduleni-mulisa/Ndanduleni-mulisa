﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.WithdrawCashToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckAccountBalanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransferFundsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePinCodeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WithdrawCashToolStripMenuItem, Me.CheckAccountBalanceToolStripMenuItem, Me.TransferFundsToolStripMenuItem, Me.ChangePinCodeToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'WithdrawCashToolStripMenuItem
        '
        Me.WithdrawCashToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.WithdrawCashToolStripMenuItem.Name = "WithdrawCashToolStripMenuItem"
        Me.WithdrawCashToolStripMenuItem.Size = New System.Drawing.Size(99, 20)
        Me.WithdrawCashToolStripMenuItem.Text = "Withdraw Cash"
        '
        'CheckAccountBalanceToolStripMenuItem
        '
        Me.CheckAccountBalanceToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.CheckAccountBalanceToolStripMenuItem.Name = "CheckAccountBalanceToolStripMenuItem"
        Me.CheckAccountBalanceToolStripMenuItem.Size = New System.Drawing.Size(144, 20)
        Me.CheckAccountBalanceToolStripMenuItem.Text = "Check Account Balance"
        '
        'TransferFundsToolStripMenuItem
        '
        Me.TransferFundsToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.TransferFundsToolStripMenuItem.Name = "TransferFundsToolStripMenuItem"
        Me.TransferFundsToolStripMenuItem.Size = New System.Drawing.Size(95, 20)
        Me.TransferFundsToolStripMenuItem.Text = "Transfer Funds"
        '
        'ChangePinCodeToolStripMenuItem
        '
        Me.ChangePinCodeToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.ChangePinCodeToolStripMenuItem.Name = "ChangePinCodeToolStripMenuItem"
        Me.ChangePinCodeToolStripMenuItem.Size = New System.Drawing.Size(108, 20)
        Me.ChangePinCodeToolStripMenuItem.Text = "Change PinCode"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents WithdrawCashToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CheckAccountBalanceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TransferFundsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ChangePinCodeToolStripMenuItem As ToolStripMenuItem
End Class
